
public class Player 
{
	String name;
    public Player(String name)
    {
    	
        this.name = name;

 
    
      
    }
    
    // return name
    public String getName()
    {
    
      return this.name;
      
    }
    
    public void setName(String n)
    {
    	
    	this.name = n;
    	
    }

	
}